const selectedConversation = {
  state: {
    selectedConversationId: '',
  }
}

export default selectedConversation