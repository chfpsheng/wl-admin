const tabsName = {
  state: {
    activeName: {},
  },
  mutations: {
    updateActiveName(state, activeName) {
      state.activeName = activeName
    }
  }
}

export default tabsName