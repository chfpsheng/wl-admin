<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>
<style scoped>
  @import url('//at.alicdn.com/t/font_2683862_2r1x1ldl8k1.css');
</style>